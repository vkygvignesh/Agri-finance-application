### Login Page: ###
![alt text](image-2.png)

### Register page ###
![alt text](image-3.png)

## Loan apply page ##
![alt text](image-4.png) 