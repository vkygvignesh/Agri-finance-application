//  import React, { useState } from 'react';
// import '../../assets/css/Registerpage.css';
//  import {  useNavigate } from 'react-router-dom';
// // import axios from 'axios';



// const RegisterPage = () => {
//   const [firstName, setFirstName] = useState('');
//   const [lastName, setLastName] = useState('');
//   const [username, setUsername] = useState('');
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [errors, setErrors] = useState({});
  
//   const navigate=useNavigate();

//   const validateForm = () => {
//     const newErrors = {};
  
//     if (firstName.trim() === '') {
//       newErrors.firstName = 'First Name is required';
//     } else if (firstName.length < 3) {
//       newErrors.firstName = 'First Name must be at least 3 characters long';
//     }
  
//     if (lastName.trim() === '') {
//       newErrors.lastName = 'Last Name is required';
//     } else if (lastName.length < 3) {
//       newErrors.lastName = 'Last Name must be at least 3 characters long';
//     }
  
//     if (username.trim() === '') {
//       newErrors.username = 'Username is required';
//     } else if (!/^[a-zA-Z]{5}[0-9]{2}$/.test(username)) {
//       newErrors.username = 'Username should be a combination of 5 alphabets and 2 numbers';
//     }
  
//     if (email.trim() === '') {
//       newErrors.email = 'Email is required';
//     } else if (!/[a-zA-Z]+@gmail.com/.test(email)) {
//       newErrors.email = 'Email should be in the format example@gmail.com';
//     }
  
//     if (password.trim() === '') {
//       newErrors.password = 'Password is required';
//     } else if (!/[A-Za-z]{3}[0-9]{2}[@$!%#?&_]{2}$/.test(password)) {
//       newErrors.password = 'Password should be a combination of 3 alphabets, 2 numbers, and 2 special characters';
//     }
//     setErrors(newErrors);
//     return Object.keys(newErrors).length === 0;
//   };
//   const handleRegister = (e) => {
//     e.preventDefault();
//     const isValid = validateForm();
//     if (isValid)
//      {
//       console.log('Registration details:', {
//         firstName,
//         lastName,
//         username,
//         email,
//         password
//       });
//     //   axios
//     //   .post("http://localhost:2023/Userdetails",
//     //   {
//     //     firstName: firstName,
//     //     lastName: lastName,
//     //     username: username,
//     //     email:email,
//     //     password:password,
//     //   })
//        then((response) => {
//          alert("participant "+ username +" added!");
//          navigate("/login");
//        }).catch(error => {
//          alert("error==="+error);
//        });
//     }
//   };

//   return (
//     <div className="reg">
//       <div className="register-container">
//         {/* <div className='tle'><h1>QUIZ APP</h1></div> */}
//         <h2>REGISTER</h2>
        // <form onSubmit={handleRegister}>
//           <div className="input-container">
//             {/* <label htmlFor="firstName" style={{color:'orange'}}><b><h3>FIRST NAME:</h3></b></label> */}
//             <input
//               type="text"
//               id="firstName"
//               placeholder='FirstName'
//               value={firstName}
//               onChange={(e) => setFirstName(e.target.value)}
//               className={errors.firstName ? 'input-error' : ''}
//             />
//             {errors.firstName && <p className="error">{errors.firstName}</p>}
//           </div>
//           <div className="input-container">
//             {/* <label htmlFor="lastName" style={{color:'orange'}}><b><h3>LAST NAME:</h3></b></label> */}
//             <input
//               type="text"
//               id="lastName"
//               placeholder='LastName'
//               value={lastName}
//               onChange={(e) => setLastName(e.target.value)}
//               className={errors.lastName ? 'input-error' : ''}
//             />
//             {errors.lastName && <p className="error">{errors.lastName}</p>}
//           </div>
//           <div className="input-container">
//             {/* <label htmlFor="username" style={{color:'orange'}}><b><h3>USER NAME</h3></b></label> */}
//             <input
//               type="text"
//               id="username"
//               placeholder='UsertName'
//               value={username}
//               onChange={(e) => setUsername(e.target.value)}
//               className={errors.username ? 'input-error' : ''}
//             />
//             {errors.username && <p className="error">{errors.username}</p>}
//           </div>
//           <div className="input-container">
//             {/* <label htmlFor="email" style={{color:'orange'}}><b><h3>EMAIL:</h3></b></label> */}
//             <input
//               type="email"
//               id="email"
//               placeholder='Email ID'
//               value={email}
//               onChange={(e) => setEmail(e.target.value)}
//               className={errors.email ? 'input-error' : ''}
//             />
//             {errors.email && <p className="error">{errors.email}</p>}
//           </div>
//           <div className="input-container">
//             {/* <label htmlFor="password" style={{color:'orange'}}><b><h3>PASSWORD:</h3></b></label> */}
//             <input
//               type="password"
//               id="password"
//               placeholder='Password '
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               className={errors.password ? 'input-error' : ''}
//             />
//             {errors.password && <p className="error">{errors.password}</p>}
//           </div>
//           <br/>
//           <button className="register-button" type="submit">
//           REGISTER
//           </button>
//         </form>
//       </div>
//     </div>
//   );
// };
// export default RegisterPage;


// if (lastName.trim() === '') {
//   newErrors.lastName = 'Last Name is required';
// } else if (lastName.length < 3) {
//   newErrors.lastName = 'Last Name must be at least 3 characters long';
// }
// App.js

//  import {  useNavigate } from 'react-router-dom';
// -----------------------------------------------
// import React, { useState } from 'react';
// import '../../assets/css/Registerpage.css';
// import rp_bg from '../../assets/images/rpage.jpg';
// import ResponsiveAppBar from '../user/Navbar';

// function RegisterPage() {
//   const [firstName, setFirstName] = useState('');
//   const [username, setUsername] = useState('');
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
  
//   const handleFirstNameChange = (e) => {
//     setFirstName(e.target.value);
//   };
  
//   const handleUsernameChange = (e) => {
//     setUsername(e.target.value);
//   };
  
//   const handleEmailChange = (e) => {
//     setEmail(e.target.value);
//   };
  
//   const handlePasswordChange = (e) => {
//     setPassword(e.target.value);
//   };
  
//    const handleSubmit = (e) => {
//        e.preventDefault();
//     //   Handle registration/authentication logic here
//     //  console.log('Registered with:', firstName, username, email, password);
//    };
//   const validateForm = () => {
//     const newErrors = {};
  
//     if (firstName.trim() === '') {
//       newErrors.firstName = 'First Name is required';
//     } else if (firstName.length < 3) {
//       newErrors.firstName = 'First Name must be at least 3 characters long';
//     }
  
  
//     if (username.trim() === '') {
//       newErrors.username = 'Username is required';
//     } else if (!/^[a-zA-Z]{5}[0-9]{2}$/.test(username)) {
//       newErrors.username = 'Username should be a combination of 5 alphabets and 2 numbers';
//     }
  
//     if (email.trim() === '') {
//       newErrors.email = 'Email is required';
//     } else if (!/[a-zA-Z]+@gmail.com/.test(email)) {
//       newErrors.email = 'Email should be in the format example@gmail.com';
//     }
  
//     if (password.trim() === '') {
//       newErrors.password = 'Password is required';
//     } else if (!/[A-Za-z]{3}[0-9]{2}[@$!%#?&_]{2}$/.test(password)) {
//       newErrors.password = 'Password should be a combination of 3 alphabets, 2 numbers, and 2 special characters';
//     }
  
//     setErrors(newErrors);
//     return Object.keys(newErrors).length === 0;
//   };
  
//     const handleRegister = (e) => {
//       e.preventDefault();
//       const isValid = validateForm();
//       if (isValid)
//       {
//         console.log('Registration details:', {
//           firstName,
//           username,
//           email,
//           password
//         });
//         then((response) => {
//           alert("participant "+ username +" added!");
//           navigate("/login");
//         }).catch(error => {
//           alert("error==="+error);
//         });
//       }
//     };
    
//     return (
//       <>
//     <ResponsiveAppBar />
//     <div className="outer-box" style={{backgroundImage:`url(${rp_bg})`}}>
//       <div className="inner-box">
//         <h2>Register</h2>
//         <form onSubmit={handleRegister}>
//           <div className="form-group">
//             <label htmlFor="firstName">First Name:</label>
//             <input
//               type="text"
//               id="firstName"
//               value={firstName}
//               onChange={handleFirstNameChange}
//               required
//               />
//           </div>
//           <div className="form-group">
//             <label htmlFor="username">Username:</label>
//             <input
//               type="text"
//               id="username"
//               value={username}
//               onChange={handleUsernameChange}
//               required
//             />
//           </div>
//           <div className="form-group">
//             <label htmlFor="email">Email:</label>
//             <input
//               type="email"
//               id="email"
//               value={email}
//               onChange={handleEmailChange}
//               required
//             />
//           </div>
//           <div className="form-group">
//             <label htmlFor="password">Password:</label>
//             <input
//               type="password"
//               id="password"
//               value={password}
//               onChange={handlePasswordChange}
//               required
//             />
//           </div>
//           <button type="submit">Register</button>
//         </form>
//       </div>
//     </div>
//     </>
//   );
// }

// export default RegisterPage;

  //   axios
  //   .post("http://localhost:2023/Userdetails",
  //   {
  //     firstName: firstName,
  //     lastName: lastName,
  //     username: username,
  //     email:email,
  //     password:password,
  //   })

  import React, { useState } from 'react';
  import '../../assets/css/Registerpage.css';
  import rp_bg from '../../assets/images/rpage.jpg';
  // import ResponsiveAppBar from '../user/Navbar';
  // import { navigate } from 'react-router-dom'; // Import navigate if you're using React Router
  import { toast } from 'react-toastify'; // Import toast from react-toastify
  import 'react-toastify/dist/ReactToastify.css'; // Import react-toastify styles
import { Link } from '@mui/material';
import {useNavigate} from 'react-router-dom'
import { signUp } from '../../services/Auth';
  
  function RegisterPage() {
    const navigate = useNavigate();
    // const [firstName, setFirstName] = useState('');
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({}); // Define errors state
  
    const handleFirstNameChange = (e) => {
      setFirstName(e.target.value);
    };
  
    const handleUsernameChange = (e) => {
      setUsername(e.target.value);
    };
  
    const handleEmailChange = (e) => {
      setEmail(e.target.value);
    };
  
    const handlePasswordChange = (e) => {
      setPassword(e.target.value);
    };
  
    const validateForm = () => {
      const newErrors = {};
  
  
      if (username.trim() === '') {
        newErrors.username = 'Username is required';
      } else if (!/^[a-zA-Z]{5}[0-9]{2}$/.test(username)) {
        newErrors.username = 'Username should be a combination of 5 alphabets and 2 numbers';
      }
  
      if (email.trim() === '') {
        newErrors.email = 'Email is required';
      } else if (!/[a-zA-Z]+@gmail.com/.test(email)) {
        newErrors.email = 'Email should be in the format example@gmail.com';
      }
  
      if (password.trim() === '') {
        newErrors.password = 'Password is required';
      } else if (!/[A-Za-z]{3}[0-9]{2}[@$!%#?&_]{2}$/.test(password)) {
        newErrors.password = 'Password should be a combination of 3 alphabets, 2 numbers, and 2 special characters';
      }
  
      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
    };
  
    const handleRegister = (e) => {
      e.preventDefault();
      const isValid = validateForm();
      if (isValid) {
        console.log('Registration details:', {
          username,
          email,
          password
        }
        );
       const data = {
              name: username,
              email: email,
              password: password
            };

        // if (username && email && password) {
        //   const data = {
        //     name: userName,
        //     email: email,
        //     password: password
        //   };
          signUp(data)
          .then(() => {
            // Navigate to sign-in page
            navigate('/login');
          })
          .catch((error) => {
            // Handle any errors
            console.error("Sign-up error:", error);
          });
          console.log(data)
    
        // Show toast message
        toast.success("Registration successful! You can now login.");
        // Reset form fields
        setUsername('');
        setEmail('');
        setPassword('');
        // Navigate to login page
        navigate("/login");
      }
    };
  
    return (
      <>
        {/* <ResponsiveAppBar /> */}
        <div className="outer-box" style={{ backgroundImage: `url(${rp_bg})` }}>
          <div className="inner-box">
            <h2 color='white'>Register</h2>
            <form onSubmit={handleRegister}>
              {/* <div className="form-group">
                <label htmlFor="firstName">First Name:</label>
                <input
                  type="text"
                  id="firstName"
                  value={firstName}
                  onChange={handleFirstNameChange}
                  required
                />
                {errors.firstName && <p className="error">{errors.firstName}</p>}
              </div> */}
              <div className="form-group">
                <label htmlFor="username">Username:</label>
                <input
                  type="text"
                  id="username"
                  value={username}
                  onChange={handleUsernameChange}
                  required
                />
                {errors.username && <p className="error">{errors.username}</p>}
              </div>
              <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={handleEmailChange}
                  required
                />
                {errors.email && <p className="error">{errors.email}</p>}
              </div>
              <div className="form-group">
                <label htmlFor="password">Password:</label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={handlePasswordChange}
                  required
                />
                {errors.password && <p className="error">{errors.password}</p>}
              </div>
               <button type="submit" >Register</button>
            </form>
          </div>
        </div>
      </>
    );
  }
  
  export default RegisterPage;
  
