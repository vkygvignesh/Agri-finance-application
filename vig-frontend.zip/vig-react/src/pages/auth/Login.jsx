import React, { useState } from 'react';
import '../../assets/css/login.css'; 
import { Link, useNavigate } from 'react-router-dom';
import { signIn } from '../../services/Auth'; // Import the signIn function
import login_bg from '../../assets/images/lopage.jpg';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  const navigate = useNavigate();

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleSignUp = (e) => {
    e.preventDefault();
    
    if (email && password) {
      const data = {
        email: email,
        password: password
      };

      signIn(data)
        .then((response) => {
          const token = response.data.token;
          const authToken = token;
          localStorage.setItem("token", authToken);
          // Navigate to sign-in page
          console.log(email);
          if (email === "admin@gmail.com") {
            navigate('/dashboard');
          } else {  
            navigate('/home');
          }
        })
        .catch((error) => {
          // Handle any errors
          console.error("Sign-up error:", error);
        });
          
        console.log(data)
  
        setEmail("");
        setPassword("");
      }
    };

  return (
    <>
      <div className="login-container" style={{backgroundImage:`url(${login_bg})`}}>
        <form className="login-form" onSubmit={handleSignUp}>
          <h2><b>LOGIN</b></h2>
          <div className="form-group">
            <label htmlFor="email"><b>Email:</b></label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={handleEmailChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password"><b>Password:</b></label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={handlePasswordChange}
              required
            />
          </div>
          <div className="log" >
            <button  onClick={handleSignUp} >
              Sign In
            </button>
          </div>
          <div className='re'>
            <br/>
            <p style={{color:"#ffffff"}}> Don't have an Account </p>
            <div className='lk'><Link to='/register'> <br/><h3>CLICK HERE</h3></Link></div>
          </div>
        </form>
      </div>
     

    </>
  );
};

export default Login;
