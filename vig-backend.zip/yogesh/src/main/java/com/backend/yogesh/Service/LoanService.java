package com.backend.yogesh.Service;

import com.backend.yogesh.dto.request.LoanRequest;
import com.backend.yogesh.dto.response.BasicResponse;
import com.backend.yogesh.dto.response.LoanResponse;

public interface LoanService {
    BasicResponse<LoanResponse> getAllLoans();
    LoanResponse createLoan(LoanRequest request);
    BasicResponse<LoanResponse> deleteLoan(String id);
    LoanResponse updateLoan(String id,LoanRequest request);
}