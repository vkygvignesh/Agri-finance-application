package com.backend.yogesh.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Loans")
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @Column(nullable = false)
    private String Loan_name;
    
    @Column(nullable = false,length =2000)
    private String Loan_price;
    
    @Column(nullable = false,length =2000)
    private String Loan_image;

   @Column(nullable = false)
    private String Loan_rating;

    @Column(nullable = false)
    private String Loan_category;

    @Column(nullable = false,length =3000)
    private String Loan_desc;

}