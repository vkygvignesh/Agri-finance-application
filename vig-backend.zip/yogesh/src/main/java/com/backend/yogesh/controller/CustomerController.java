package com.backend.yogesh.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.backend.yogesh.Service.CustomerService;
import com.backend.yogesh.dto.request.CustomerRequest;
import com.backend.yogesh.dto.request.LoanRequest;
import com.backend.yogesh.dto.response.BasicResponse;
import com.backend.yogesh.dto.response.CustomerResponse;
import com.backend.yogesh.dto.response.LoanResponse;
import com.backend.yogesh.model.Customer;
import com.backend.yogesh.Utils.myconstant;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/customer")
@RequiredArgsConstructor
public class CustomerController {
    private final CustomerService CustomerService;
    @GetMapping("/get")
    public ResponseEntity<BasicResponse<CustomerResponse>> create(){
        BasicResponse<CustomerResponse> response=new BasicResponse<>();
        try{
            response=CustomerService.getAllCustomer();
            return new ResponseEntity<>(response,HttpStatus.OK);
        }
        catch(Exception e){
            response.setMessage("Something went wrong!");
            return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
        }
    }
    @PostMapping("/add")
    public ResponseEntity<CustomerResponse> createcustomer(@RequestBody CustomerRequest request) {
        CustomerResponse response = new CustomerResponse();
        try {
            response = CustomerService.createCustomer(request);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch(Exception e) {
            response.setMessage("Something went Wrong!");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}