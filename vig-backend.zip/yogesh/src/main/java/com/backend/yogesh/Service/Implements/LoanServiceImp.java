package com.backend.yogesh.Service.Implements;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;

import com.backend.yogesh.model.Loan;
import com.backend.yogesh.repository.LoanRepository;
import com.backend.yogesh.Service.LoanService;
import com.backend.yogesh.dto.request.LoanRequest;
import com.backend.yogesh.dto.response.BasicResponse;
import com.backend.yogesh.dto.response.LoanResponse;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LoanServiceImp implements LoanService {
    private final LoanRepository LoanRepo;

    @Override
    public BasicResponse<LoanResponse> getAllLoans() 
    {
        List<Loan> Loans = LoanRepo.findAll();
        List<LoanResponse> LoanResponses = Loans.stream()
            .map(Loan -> LoanResponse.builder()
                .id(Loan.getId())
                .Loan_name(Loan.getLoan_name())
                .Loan_price(Loan.getLoan_price())
                .Loan_image(Loan.getLoan_image())
                .Loan_rating(Loan.getLoan_rating())
                .Loan_category(Loan.getLoan_category())
                .Loan_desc(Loan.getLoan_desc())
                .build())
            .collect(Collectors.toList());
        return BasicResponse.<LoanResponse>builder()
            .message("success!")
            .data(LoanResponses)
            .build();
    }

    private final LoanRepository LoanRepository;
    @Override
    public LoanResponse createLoan(LoanRequest request) {
        Loan loan = Loan.builder()
            .Loan_name(request.getLoan_name())
            .Loan_price(request.getLoan_price())
            .Loan_image(request.getLoan_image())
            .Loan_rating(request.getLoan_rating())
            .Loan_category(request.getLoan_category())
            .Loan_desc(request.getLoan_desc())
            .build();
        LoanRepository.save(loan);
        return LoanResponse.builder()
            .message("Loan created successfully")
            .build();
    }

    @Override
        public BasicResponse<LoanResponse> deleteLoan(String LoanId) {
            if (LoanRepository.existsById(LoanId)) {
                LoanRepository.deleteById(LoanId);
                return BasicResponse.<LoanResponse>builder()
                    .message("Loan deleted successfully")
                    .build();
            } else {
                return BasicResponse.<LoanResponse>builder()
                    .message("Loan not found with ID: " + LoanId)
                    .build();
            }
        }

        @Override
        public LoanResponse updateLoan(String LoanId, LoanRequest request) {
            if (LoanRepository.existsById(LoanId)) {
                Loan existingLoan = LoanRepository.findById(LoanId).orElse(null);
                if (existingLoan != null) {
                    existingLoan.setLoan_name(request.getLoan_name());
                    existingLoan.setLoan_price(request.getLoan_price());
                    existingLoan.setLoan_image(request.getLoan_image());
                    existingLoan.setLoan_rating(request.getLoan_rating());
                    existingLoan.setLoan_category(request.getLoan_category());
                    existingLoan.setLoan_desc(request.getLoan_desc());
                    LoanRepository.save(existingLoan);
                    return LoanResponse.builder()
                        .message("Loan updated successfully")
                        .build();
                } else {
                    return LoanResponse.builder()
                        .message("Failed to update Loan. Loan not found with ID: " + LoanId)
                        .build();
                }
            } else {
                return LoanResponse.builder()
                    .message("Failed to update Loan. Loan not found with ID: " + LoanId)
                    .build();
            }
        }
}