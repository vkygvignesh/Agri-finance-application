package com.backend.yogesh.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class LoanRequest
{
    private String Loan_name;
    private String Loan_price;
    private String Loan_image;
    private String Loan_rating;
    private String Loan_category;
    private String Loan_desc;
}

    
