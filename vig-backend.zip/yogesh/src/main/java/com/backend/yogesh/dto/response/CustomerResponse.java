package com.backend.yogesh.dto.response;

import com.backend.yogesh.model.User;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerResponse {
    private String message;
    private String customerId;
    private String firstname;
    private String lastname;
    private String place;
    private String aadharnumber;
    private String type;
    private String loanamount;
    private String phnumber;
    private String income;

}
