package com.backend.yogesh.enumaretor;

public enum Role {
    ADMIN, USER
}
